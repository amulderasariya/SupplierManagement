<template>
	<div class="-mx-4 mt-8 flex flex-col sm:-mx-6 md:mx-0">
		<dl class="min-w-full flex justify-between border-b border-gray-200">
			<dt>Department</dt>
			<dd class="pt-4 text-right text-sm text-gray-500">Entertainment</dd>
		</dl>
		<dl class="min-w-full flex justify-between border-b border-gray-200">
			<dt>Category</dt>
			<dd class="pt-4 text-right text-sm text-gray-500">Cameras and Supply</dd>
		</dl>
		<dl class="min-w-full flex justify-between border-b border-gray-200">
			<dt>Sub Category</dt>
			<dd class="pt-4 text-right text-sm text-gray-500">Sony</dd>
		</dl>
		<dl class="min-w-full flex justify-between border-b border-gray-200">
			<dt>Stock</dt>
			<dd class="pt-4 text-right text-sm text-gray-500">78</dd>
		</dl>
	</div>
</template>

<script setup></script>
